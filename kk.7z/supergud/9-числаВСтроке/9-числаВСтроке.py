#!Дан текстовый файл, состоящий из одной или нескольких строк. Каждая строка файла содержит числа, разделенные пробелами. Удалить 
#из файла все числа, меньшие заданного числа. Если таких чисел нет, оставить его без изменений.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def save():
    try: # проверка формата файла
        file = open(ent.get(), 'r', encoding = 'utf-8')
        text = file.read().split('\n')
        for i in range(len(text)): # создание списка чисел из содержимого файла
            text[i] = list(map(int,text[i].split(' ')))
        inpnum = int(ent2.get())
    except:
        mb.showerror('Ошибка!', 'Неверный формат файла!')
        return
    newtext = '' # переменная для результата
    for line in text: # цикл по строкам
        for num in line: # цикл по числам в строке
            if num >= inpnum: # если число меньше введенного, то не сохраняем
                newtext += str(num)+' '
        newtext = newtext[:-1] + '\n'
    file = open(ent.get(), 'w', encoding = 'utf-8') # перезаписываем файл
    file.write(newtext[:-1])
    file.close()
    mb.showinfo('Успешно!','Файл изменен!')

def chfile(): # открытие файла через ask
    ent.delete(0, 'end')
    ent.insert('end', ask())
    ent.xview_moveto(1)

r = Tk()
r.title('Билет 5')
r.geometry('450x90')
r.resizable(0, 0)
lbl = Label(text = 'Выберите файл:', font = 'Consolas 12')
lbl.place(x = 10, y = 10)
ent = Entry(font = 'Consolas 14', width = 20)
ent.place(x = 150, y = 10)
lbl = Label(text = 'Введите число для сравнения:', font = 'Consolas 12')
lbl.place(x = 10, y = 50)
ent2 = Entry(font = 'Consolas 14', width = 4)
ent2.place(x = 265, y = 50)
btn = Button(text = '...', font = 'Consolas 10')
btn.bind('<Button-1>', lambda x: chfile())
btn.place(x = 365, y = 10)
btn2 = Button(text = 'Сохранить', font = 'Consolas 10')
btn2.bind('<Button-1>', lambda x: save())
btn2.place(x = 325, y = 50)
r.mainloop()
