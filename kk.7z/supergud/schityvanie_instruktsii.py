import tkinter.messagebox
def inst():
    if os.path.exists('inst.txt') == True:
        f = open('inst.txt','r', encoding = 'utf-8')
        readd = f.read()
        f.close()
        tkinter.messagebox.showinfo(title = "Инструкция", message = readd)
    else:
        tkinter.messagebox.showerror(title = "Ошибка", message = 'Файл не обнаружен')

def info():
    if os.path.exists('info.txt') == True:
        f = open('info.txt','r', encoding = 'utf-8')
        readd = f.read()
        f.close()
        tkinter.messagebox.showinfo(title = "О программе", message = readd)
    else:
        tkinter.messagebox.showerror(title = "Ошибка", message = 'Файл не обнаружен')
