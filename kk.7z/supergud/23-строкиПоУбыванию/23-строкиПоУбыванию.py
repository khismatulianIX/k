#!Дан текстовый файл. Перепишите его содержимое в новый файл, предварительно отсортировав строки по убыванию. Предусмотреть 
#предварительный просмотр файла до чистки и после. Открывать файл для редактирования в диалоговом режиме, имя текстового файла 
#также вводится или выбирается.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def rsort(a): # быстрая сортировка
    if a == []:
        return a
    l = [i for i in a if i > a[0]]
    m = [i for i in a if i == a[0]]
    r = [i for i in a if i < a[0]]
    return rsort(l) + m + rsort(r)

def sort(): # сортировка строк
    text = tx1.get(1.0, 'end').split('\n')
    newtext = '\n'.join(rsort(text))
    tx2.delete(1.0, 'end')
    tx2.insert(1.0,newtext)
    file = open('result.txt', 'w', encoding = 'utf-8') # запись в файл
    file.write(newtext)
    file.close()
    mb.showinfo('Успешно!','Файл с результатом создан!')

def chfile(): # открытие файла через ask
    ent.delete(0, 'end')
    ent.insert('end', ask())
    ent.xview_moveto(1)

def gofile(): # попытка открыть файл
    try:
        file = open(ent.get(), 'r', encoding = 'utf-8')
        text = file.read()
    except:
        mb.showerror('Ошибка!', 'Неверный формат файла!')
        return
    tx1.delete(1.0, 'end')
    tx2.delete(1.0, 'end')
    tx1.insert(1.0,text)

r = Tk()
r.title('Билет 23')
r.geometry('500x340')
r.resizable(0, 0)
ent = Entry(font = 'Consolas 14', width = 20)
ent.place(x = 150, y = 10)
btn = Button(text = '...', font = 'Consolas 10')
btn.bind('<Button-1>', lambda x: chfile())
btn.place(x = 365, y = 10)
btn1 = Button(text = 'Открыть', font = 'Consolas 10')
btn1.bind('<Button-1>', lambda x: gofile())
btn1.place(x = 410, y = 10)
lbl = Label(text = 'Выберите файл:', font = 'Consolas 12')
lbl.place(x = 10, y = 10)
tx1 = Text(width = 28, height = 15)
tx1.place(x = 15, y = 50)
tx2 = Text(width = 28, height = 15)
tx2.place(x = 255, y = 50)
btn2 = Button(text = 'Отсортировать', font = 'Consolas 10')
btn2.bind('<Button-1>', lambda x: sort())
btn2.place(x = 15, y = 305)
r.mainloop()
