# Размещение квадратной матрицы в ячейках, сортировка строки и столбца
from tkinter import *
from random import randint
from tkinter.filedialog import *
def EXIT(event):
    root.destroy()
    
def Matrica(event):
    event.widget["activeforeground"] = "Green"
    win.destroy()
    sw=[]
    mw=[]
    # Первая встроенная в Matrica функция
    def Sortirovka(event):
        event.widget["activeforeground"] = "Green"
        a=[]
        for i in range(len(mat)):
            c=0
            for j in range(len(mat[0])):
                if mat[i][j]>0:
                    c=c+mat[i][j]
            a.append(c)
        lb1=Label(fra, text='Сумма всех положительных элементов каждой строчки', font='Areal 12',bg='Aqua')
        hh=23*n+80 # 23-высота ячейки в пикселях
        lb1.place(x=17,y=hh)
        h=25
    
        for j in range(n):
            b=Entry(fra, bg='White', width=5,font='Areal 12', justify=CENTER)
            b.insert(0,str(a[j]))
            b.place(x=h, y=hh+23)
            h+=50
            
        # Клавиша Выход
        but_exit = Button(fra, text="Выход", font='Areal 12', bg='White', fg='Black')
        but_exit.place(x=h+30,y=hh+70)
        but_exit.bind("<Button-1>", EXIT)
        def Save(event):
            os = asksaveasfilename() # Открытие папки и выбор файла для записи
            q = open(os,'w')
            q.write(str(a))
            q.close()
        but_save=Button(fra, text='Сохранить',font='Areal 12', bg='White', fg='Black')
        but_save.place(x=h+30,y=hh+30)
        but_save.bind("<Button-1>", Save)
    # тело функции Matrica
    n=0# считываем размерность
    n=n+2
    m=5
    fra.configure(width=50*n+335,height=23*n+250) # Изменяем размер окна по размерности
        # матрицы, 50*23-размер ячейки Entry
    mat=[[randint(-10,10)for j in range(m)] for i in range(n)] # Задаем матрицу
    h=25 # Начальное положение первой ячейки по х
    hh=80 # Начальное положение первой ячейки по у
    for i in range(n): # Цикл по строкам
        for j in range(m): # Цикл по столбцам
            if i==3 or j ==3:
                a=Entry(fra, bg='White', width=5,font='Areal 12', justify=CENTER)
                sw.append(a)
            else:
                a=Entry(fra, bg='White',fg='Black', width=5,font='Areal 12', justify=CENTER)
            a.insert(0,str(mat[i][j])) # Помещаем в окно соответствующий элемент матрицы
            a.place(x=h, y=hh)
            h+=50

        h=25
        hh+=23
        mw.append(sw)
    b2 = Button(fra, text="Сложить",font='Areal 12',bg='White',fg='Black')
    b2.place(x=230,y=40)
    b2.bind('<Button-1>', Sortirovka)

# Основная программа
x = 'Сформировать двумерный массив С\nразмером N х 5 (N - количество строк, равное последней цифре номера студенческого\n билета+2; 5 - количество столбцов)\nс помощью генератора случайных чисел \nвывести элементы массива на экран и в\nфайл. Вычислить сумму положительных\nэлементов в каждой строке матрицы С\n(оформить вычисление сумм в виде\nпроцедуры). Из полученных сумм составить одномерный массив D. Вывести элементы\nмассива D на экран и в файл.'       
root=Tk()
root.title('Мevent.widget["activeforeground"] = "Green"атрица по номеру студенческого билета')
fra=Frame(root, width=500,height=500,bg='Aqua')
fra.grid(row=0,column=0)
win = Text(fra, width = 40,height = 13, font = 'Arial 13', bg = '#FFF', fg='blue')
win.insert(END,x)
win.place(x=70,y=80)
lb=Label(fra, text='Количество строк по номеру студенческого билета 0 (+2)', font='Areal 12',bg='Aqua')
lb.place(x=17,y=10)
b1 = Button(fra, text="Обновить матрицу",font='Areal 12',bg='White',fg='Black')
b1.place(x=30,y=40)
b1.bind('<Button-1>', Matrica)
root.mainloop()
