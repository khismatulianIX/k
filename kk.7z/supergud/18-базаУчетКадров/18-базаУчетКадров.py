#!Создать программу, которая отображает таблицу из базы данных "Учет кадров" (Сотрудники: табельный номер, фамилия, дата рождения, 
#код специальности, код подразделения, дата приема, дата начала трудовой деятельности, оклад, образование, код должности). 
#Предусмотреть просмотр и добавление данных. Создать запрос на выборку по фамилии работника и по табельному номеру.
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sqlite3, sys


class Example(QMainWindow): # Создание окна
    
    def __init__(self):
        super().__init__()
        central_widget = QWidget(self)
        self.setWindowTitle('Билет 18')
        self.setCentralWidget(central_widget)
        grid_layout = QGridLayout()
        central_widget.setLayout(grid_layout)
        self.count = len(data)
        self.table = QTableWidget(self) # Создание таблицы
        self.table.setColumnCount(len(cols))
        self.table.setRowCount(self.count)
        self.table.setHorizontalHeaderLabels(cols)
        for i in range(self.count): # Заполнение таблицы
            for j in range(len(cols)):
                self.table.setItem(i, j, QTableWidgetItem(str(data[i][j])))
        self.table.resizeColumnsToContents()
        grid_layout.addWidget(self.table, 0, 0)

        self.btn = QPushButton('Добавить запись', self) # Создание кнопок
        grid_layout.addWidget(self.btn, 2, 0)
        self.btn.clicked.connect(self.addzap)
        self.btn2 = QPushButton('Сохранить базу', self)
        grid_layout.addWidget(self.btn2, 3, 0)
        self.btn2.clicked.connect(self.save)
        self.qle = QLineEdit(self) # Создание поля ввода
        self.qle.setPlaceholderText("Таб. номер")
        grid_layout.addWidget(self.qle, 4, 0)
        self.qle2 = QLineEdit(self)
        self.qle2.setPlaceholderText("Фамилия")
        grid_layout.addWidget(self.qle2, 5, 0)
        self.btn3 = QPushButton('Запрос', self) # Создание кнопки запроса
        grid_layout.addWidget(self.btn3, 6, 0)
        self.btn3.clicked.connect(self.zapr)
        
    def addzap(self): # добавление записи
        if self.count == len(data):
            self.zapr(1)
        self.count += 1
        self.table.setRowCount(self.count)
        for j in range(len(cols)):
            self.table.setItem(self.count-1, j, QTableWidgetItem(''))

    def save(self): # сохранение в базу
        if self.count == len(data):
            QMessageBox.about(self, "Ошибка", "Нет новых записей для внесения в базу!")
            return
        newdata = []
        for i in range(len(data),self.count): # сбор данных
            newdata += [[]]
            for j in range(len(cols)):
                newdata[-1] += [self.table.item(i, j).text()]
        try: # попытка записи
            cursor.executemany('insert into employees values(?,?,?,?,?,?,?,?,?,?)',newdata)
            conn.commit()
            QMessageBox.about(self, "Успешно", "Новые записи добавлены в базу!")
        except:
            QMessageBox.about(self, "Ошибка", "Новые записи содержат ошибку и не могут быть добавлены в базу!")

    def zapr(self, x = 0): # запрос
        self.count = len(data)
        self.table.setRowCount(0) # Очистка таблицы
        self.table.setRowCount(len(data))
        ii = 0
        for i in range(len(data)): # Заполнение таблицы
            if (str(data[i][0]) == self.qle.text() or self.qle.text() == '') and (data[i][1] == self.qle2.text() or self.qle2.text() == '') or x == 1:
                for j in range(len(cols)):
                    self.table.setItem(ii, j, QTableWidgetItem(str(data[i][j])))
                ii += 1

conn = sqlite3.connect("personnelRecord.db") # Чтение из базы
cursor = conn.cursor()
data = cursor.execute("select * from employees").fetchall()
cols = ['таб. номер', 'фамилия', 'дата рождения', 'код специальности', 'код подразделения',
        'дата приема', 'дата начала тр. деятельности', 'оклад', 'образование', 'код должности']
app = QApplication(sys.argv)
w = Example()
w.show()
app.exec_()
