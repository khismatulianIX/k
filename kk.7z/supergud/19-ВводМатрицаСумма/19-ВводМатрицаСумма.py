from tkinter import Tk, Button
from os import startfile

root = Tk()
root.title('Билет 19')
root.geometry('205x55')
root.resizable(0, 0)
btn = Button(root,text = 'Начать ввод матрицы', font = 'Consolas 12')
btn.bind('<Button-1>', lambda x: startfile('main.py'))
btn.place(x = 10, y = 10)
root.mainloop()
