#!Разработать две программы. Первая принимает от пользователя квадратную матрицу, вычисляет сумму элементов, не лежащих на главной и 
#побочной диагоналях, и выводит на экран. Вторая программа запускает первую в качестве вновь созданного процесса.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def matrix():
    text = tx1.get(1.0, 'end')
    try: # проверка введенной матрицы на соответствие
        length = len(text[:text.index('\n')].split(' ')) # определение длины и ширины
        lines = text.replace('\n', ' ')[:-1] # сбор чисел в один список
        matrix = list(map(int, lines.split(' '))) # разбиение введенной матрицы на список чисел
        if len(matrix) / length != length: # проверка на квадратность
            mb.showerror('Ошибка!', 'Не является квадратной матрицей!')
            return
    except:
        mb.showerror('Ошибка!', 'Некорректный ввод матрицы!')
        return
    tx1.delete(1.0, 'end')
    cursor = 0 # счетчик для определения диагоналей
    sums = 0 # сумма
    for i in range(0, len(matrix), length): # проход по списку чисел
        row = list(map(str,matrix[i:i+length])) # определение строки
        for j in range (len(row)): # цикл по числам в строке
            if j != cursor and j != length - cursor - 1: # проверка на диагонали
                sums += int(row[j])
        tx1.insert('end', ' '.join(row)+'\n')# запись матрицы обратно в поле
        cursor += 1
    sums = str(sums)
    tx1.insert('end', '\nСумма чисел, не лежащих на главной\n' +
               'и побочной диагоналях: ' + sums)    

r = Tk()
r.title('Билет 10')
r.geometry('330x360')
r.resizable(0, 0)
lb2 = Label(r, text = 'Введите матрицу:', font = 'Consolas 12')
lb2.place(x = 10, y = 10)
tx1 = Text(r, width = 37, height = 16)
tx1.place(x = 15, y = 45)
btn = Button(r, text = 'Рассчитать сумму', font = 'Consolas 12')
btn.bind('<Button-1>', lambda x: matrix())
btn.place(x = 15, y = 315)
r.mainloop()
