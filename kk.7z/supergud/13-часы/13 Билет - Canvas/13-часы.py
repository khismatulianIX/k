from tkinter import Tk,Canvas
from PIL import ImageTk,Image

def mover(e,i):
    if e.type=='6': return c.coords(colors[i],e.x-10,e.y-10,e.x+10,e.y+10)
    c.coords(colors[i],10+i*30,310,30+i*30,330)
    if 1 in c.find_overlapping(e.x,e.y,e.x,e.y): c.itemconfig('clock',fill=colors[i])

r = Tk()
r.title('Билет 13')
r.resizable(0,0)
c=Canvas(width=300,height=350)
img=ImageTk.PhotoImage(Image.open("1.png").resize((300,300),1))
c.create_oval(20,20,280,280,fill='green',outline='',tag='clock')
c.create_image(150,150,image=img)
colors=['red','green','yellow','skyblue','gray','white','magenta','lime','salmon','orange']
for i in range(10):
    c.create_oval(7+i*30,310,27+i*30,330,fill=colors[i],outline='',tag=colors[i])
    c.tag_bind(colors[i],'<B1-Motion>',lambda x,i=i: mover(x,i))
    c.tag_bind(colors[i],'<ButtonRelease-1>',lambda x,i=i: mover(x,i))
c.pack()
r.mainloop()
