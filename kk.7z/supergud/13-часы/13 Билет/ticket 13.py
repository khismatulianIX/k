#!Создать проект, который содержит изображение циферблата часов, состоящего из компонентов Shape. Используя интерфейс Drag&Drop, 
#изменять цвета циферблата на цвет, выбранный пользователем из имеющейся палитры.
import sys

from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

from PyQt5.QtWidgets import (QPushButton, QWidget,
    QLineEdit, QApplication)


class Button(QPushButton):

    def __init__(self, title, parent):
        super().__init__(title, parent)

        self.setAcceptDrops(True)


    def dragEnterEvent(self, e):

        if e.mimeData().hasFormat('text/plain'):
            e.accept()
        else:
            e.ignore()

    def dropEvent(self, e):
        e = e.mimeData().text()
        if e == 'Red':
            self.setStyleSheet('background: rgb(255, 0, 0);')
        elif e == 'Orange':
            self.setStyleSheet('background: rgb(255, 165, 0);')
        elif e == 'Yellow':
            self.setStyleSheet('background: rgb(255, 255, 0);')
        elif e == 'Green':
            self.setStyleSheet('background: rgb(0, 128, 0);')
        elif e == 'Cyan':
            self.setStyleSheet('background: rgb(0, 255, 255);')
        elif e == 'Blue':
            self.setStyleSheet('background: rgb(0, 0, 255);')
        elif e == 'Violet':
            self.setStyleSheet('background: rgb(238, 130, 238);')
            
        


class Example(QWidget):

    def __init__(self):
        super().__init__()

        self.initUI()


    def initUI(self):

        edit = QLineEdit('Red', self)
        edit.setDragEnabled(True)
        edit.setReadOnly(True)
        edit.move(30, 65)

        edit1 = QLineEdit('Orange', self)
        edit1.setDragEnabled(True)
        edit1.setReadOnly(True)
        edit1.move(30, 90)

        edit2 = QLineEdit('Yellow', self)
        edit2.setDragEnabled(True)
        edit2.setReadOnly(True)
        edit2.move(30, 115)

        edit3 = QLineEdit('Green', self)
        edit3.setDragEnabled(True)
        edit3.setReadOnly(True)
        edit3.move(30, 140)

        edit4 = QLineEdit('Cyan', self)
        edit4.setDragEnabled(True)
        edit4.setReadOnly(True)
        edit4.move(30, 165)


        edit5 = QLineEdit('Blue', self)
        edit5.setDragEnabled(True)
        edit5.setReadOnly(True)
        edit5.move(30, 190)

        edit6 = QLineEdit('Violet', self)
        edit6.setDragEnabled(True)
        edit6.setReadOnly(True)
        edit6.move(30, 215)

        

        button = Button("", self)
        button.setIcon(QIcon('p.png'))
        button.setIconSize(QSize(75, 75))
        button.move(270, 65)

        self.setWindowTitle('Simple drag & drop')
        self.setGeometry(300, 300, 600, 550)


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    app.exec_()
