######Сумма элементов списка######
    #Четность индексов
a=[2,2,2] #некий список
s=0
for i in range(len(a)):   #n-количество элементов
    s += a[i]    
    #Четность элементов
a=[2,2,2] #некий список
s=0
for elem in a:
    s+=elem
    #сумма положительных элементов с четным индексом
s=sum([a[i] for i in range(len(a)) if a[i]>0 and i%2==0])


######Количество элементов в списке#######
kol=0
for i in range(len(a)):
    if <Некое условие>:
       kol+=1       
    # в питоне можно так
kol=len([a[i] for i in range(len(a) if <Некое условие>)])


######Запись из одного списка в другой#######
b=[]
for i in range(len(a)):
    if <Некое условие>:
       b.append(a[i])       
    # в питоне можно так
b=[a[i] for i in range(len(a)) if ...]
b=[elem for elem in a if ...]


######Поиск индекса первого элемента#######
#если использовать .index(), то он может привести к ошибке, если элемент не найден
isk_index =-1
for i in range(len(a)):
    if <Некое условие>:
       isk_index = i
       break
if isk_index>-1:
    print(isk_index, ' индекс этого элемента')
else:
    print('Нет такого элемента')


######Макс/Мин#######
m=a[0]
for i in range(1,len(a)):
    if a[i]>m:   #здесь если макс-">" , если мин-"<"
        m=a[i]
    #Для поиска индекса макс/мин элемента
m=a[0]
ind_max=0
for i in range(1,len(a)):
    if a[i]>m:   #здесь если макс-">" , если мин-"<"
        m=a[i]
        ind_max=i
    #нахождение второго по величине значения в списке
max1=max(a)
ind_max1=a.index(max1)
b=[a[i] for i in range(len(a)) if i!= ind_max1]
max2=max(b)


######Инвертирование списка######
for i in range(len(a)//2):
    listt=a[i]
    a[i]=a[len(a)-i-1]
    a[len(a)-i-1]=listt
    # в питоне можно так
a[i],a[len(a)-i-1]=a[len(a)-i-1],a[i]


######Удаление элемента из списка с заданной позицией k######
for i in range(k-1,len(a)-1):
    a[i]=a[i+1]
a.pop(n-1)


######Вставка элемента в позицию k######
a.append('') #возможно в кавычки нужен пробел
for i in range(len(a)-1,k-1,1):
    a[i]=a[i-1]
    a[k-1]=x
