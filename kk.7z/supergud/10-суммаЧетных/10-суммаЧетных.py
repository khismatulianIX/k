#!Дан текстовый файл, содержащий квадратную матрицу. Элементы разделены пробелами. Проверить, содержится ли в матрице заданное 
#число. Найти сумму и количество чётных чисел матрицы. Результаты с соответствующими комментариями дописать в исходный файл. 
#Предложить на выбор несколько наборов матриц (каждая в отдельном файле) в диалоговом режиме.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label

def matrix():
    try: # проверка введенного числа
        inputnum = int(ent.get())
    except:
        lbl.config(text = 'Не введено целое число!')
        return 
    sums = 0 # переменная для суммы
    inlist = False # проверка вхождения введенного числа в лист
    filename = ask() #открытие файла
    file = open(filename, 'r', encoding = 'utf-8')
    try: # проверка формата файла
        lines = file.read().split('\n')
        for line in lines: # цикл по строкам
            line = list(map(int, line.split(' '))) # разбиение строки на список чисел
            for num in line: # цикл по числам в строке
                if num % 2 == 0: # суммирование четных
                    sums += num
            if inputnum in line: # проверка на вхождение в массив введенного числа
                inlist = True
    except:
        lbl.config(text = 'Неверный формат!')
        file.close()
        return 
    file = open(filename, 'a', encoding = 'utf-8') # сохранение в файл
    file.write('\n\nНаличие числа ' + str(inputnum) + ' в матрице: ' +
               str(inlist) + '\nСумма четных чисел: ' + str(sums))
    file.close()
    lbl.config(text = 'Успешно!')

r = Tk()
r.title('Билет 10')
r.geometry('265x130')
r.resizable(0, 0)
btn = Button(text = 'Выбрать файл с матрицей', font = 'Consolas 14')
btn.bind('<Button-1>', lambda x: matrix())
btn.place(x = 10, y = 10)
ent = Entry(font = 'Consolas 14', width = 24)
ent.place(x = 10, y = 95)
lbl = Label(text = 'Введите целое число', font = 'Consolas 14')
lbl.place(x = 10, y = 60)
r.mainloop()
